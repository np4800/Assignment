# You can create more variables according to your project. The following are the basic variables that have been provided to you
DB_PATH = 
DB_FILE_NAME = 
UNIT_TEST_DB_FILE_NAME = 
DATA_DIRECTORY = 
INTERACTION_MAPPING = 
INDEX_COLUMNS = 
NOT_FEATURES = 

