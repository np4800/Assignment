DB_PATH = 
DB_FILE_NAME = 

DB_FILE_MLFLOW = 

TRACKING_URI = 
EXPERIMENT =


# model config imported from pycaret experimentation
model_config = 

# list of the features that needs to be there in the final encoded dataframe
ONE_HOT_ENCODED_FEATURES = 
# list of features that need to be one-hot encoded
FEATURES_TO_ENCODE = 
