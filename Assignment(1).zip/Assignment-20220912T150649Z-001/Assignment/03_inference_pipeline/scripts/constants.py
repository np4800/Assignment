DB_PATH = 
DB_FILE_NAME = 

DB_FILE_MLFLOW = 

FILE_PATH = 

TRACKING_URI = 

# experiment, model name and stage to load the model from mlflow model registry
MODEL_NAME = 
STAGE = 
EXPERIMENT = 

# list of the features that needs to be there in the final encoded dataframe
ONE_HOT_ENCODED_FEATURES = 

# list of features that need to be one-hot encoded
FEATURES_TO_ENCODE = 
